;********************************************************************************
;* @file        target_ap.s
;* @version     $Rev:: 563          $
;* @date        $Date:: 2025-06-26 #$
;* @brief       Include AP image
;*
;* @note        Copyright (C) Holtek Semiconductor Inc. All rights reserved.
;*
;* <h2><center>&copy; COPYRIGHT Holtek</center></h2>
;*
;********************************************************************************
;*----------- <<< Use Configuration Wizard in Context Menu >>> ------------------
;********************************************************************************

TARGET_CHIP         EQU     0

USER_DEFINE         EQU     0
HT32F42366_76_86    EQU     36

;============================================================================================================
; !!! NOTICED !!!
; Use plaintext image when #define ARC4_DECRYPTION_EN (0) in "iap_config.h" of IAP_UART_Slave (AP_Plaintext.bin or AP_xxxxx_Plaintext.bin)
; Use encrypted image when #define ARC4_DECRYPTION_EN (1) in "iap_config.h" of IAP_UART_Slave (AP_Encrypt.bin or AP_xxxxx_Encrypt.bin)
;============================================================================================================

        AREA    TARGET_AP, DATA, READONLY

          IF (TARGET_CHIP=USER_DEFINE)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_Encrypt.bin
          ENDIF

          IF (TARGET_CHIP=HT32F42366_76_86)
            ;INCBIN  ../../IAP_UART_Slave/Tools/AP_42386_Plaintext.bin
            INCBIN  ../../IAP_UART_Slave/Tools/AP_42386_Encrypt.bin
          ENDIF

        AREA    TARGET_DIGEST, DATA, READONLY

          IF (TARGET_CHIP=USER_DEFINE)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_Encrypt_digest.bin
          ENDIF

          IF (TARGET_CHIP=HT32F42366_76_86)
            INCBIN  ../../IAP_UART_Slave/Tools/AP_42386_Encrypt_digest.bin
          ENDIF

        END
